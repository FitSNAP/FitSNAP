#!/bin/bash
repin=$1
tolin=$2
exe="/ascldap/users/mitwood/Documents/LAMMPS_Builds/trunk/src/lmp_kokkos_mpi_only"
pair_file="potential.mod"
cores=36

############Defect Formation Energies######################
j=0
rm -f lastcol2 tmp_defectE.dat Summary.dat
alat=3.1804
mass1=183.84
mass2=9.012182
xtal=bcc
type=1
for rep in $(seq $repin 1 $repin)
do
for tol in $(seq $tolin 2 $tolin)
do
j=0
rm -f lastcol2 tmp_defectE.dat
for i in perf_bcc tet_bcc oct_bcc 110d_bcc 111d_bcc vac_bcc divac_bcc
do
let j=$j+1
mpiexec -np ${cores} ${exe} -in in.snap_${i} -v pairfile ${pair_file} -v size ${rep} -v elimit 1E-${tol} -v flimit 1E-${tol} -v alat ${alat} -v mass1 ${mass1} -v mass2 ${mass2} -v type ${type} > log.${i}_${rep}_${tol}
rperf_petot=`grep "RELAXED PE PEATOM" log.perf_bcc_${rep}_${tol} | awk '{print($4)}'`
rperf_peatom=`grep "RELAXED PE PEATOM" log.perf_bcc_${rep}_${tol} | awk '{print($5)}'`
rel_petot=`grep "RELAXED PE PEATOM" log.${i}_${rep}_${tol} | awk '{print($4)}'`
rel_peatom=`grep "RELAXED PE PEATOM" log.${i}_${rep}_${tol} | awk '{print($5)}'`
if [ ${#rel_petot} -gt 0 ]; then
echo $i "PEATOM" $rel_petot $rperf_peatom $rep $tol >> tmp_defectE.dat
else
echo $i " PEATOM 0.0 " $rperf_peatom $rep $tol >> tmp_defectE.dat
fi
mv tmp.dump Relaxed_${i}.dump
done
mv tmp_defectE.dat ${rep}_${tol}_defectE.dat

############Error Calculation######################
input=${rep}_${tol}_defectE.dat
wtet=`awk '{if($1=="tet_bcc")    print($3-($4*(2.0*'"$rep"'**3+1)))}' $input`
woct=`awk '{if($1=="oct_bcc")    print($3-($4*(2.0*'"$rep"'**3+1)))}' $input`
w110d=`awk '{if($1=="110d_bcc") print($3-($4*(2.0*'"$rep"'**3+1)))}' $input`
w111d=`awk '{if($1=="111d_bcc") print($3-($4*(2.0*'"$rep"'**3+1)))}' $input`
wvac=`awk '{if($1=="vac_bcc")    print($3-($4*(2.0*'"$rep"'**3-1)))}' $input`
wdivac=`awk '{if($1=="divac_bcc")    print($3-($4*(2.0*'"$rep"'**3-2))-2.0*'"$wvac"')}' $input`

echo $wtet  " W_Tetra_SIA   (11.05)"
echo $woct  " W_Octa_SIA    (11.70)"
echo $w110d " W_110d_SIA    (9.84)"
echo $w111d " W_111d_SIA    (9.55)"
echo $wvac  " W_Vacncy_SIA  (3.27)"
echo $wdivac " Divacancy_1NN_Binding (0.12)"
echo "W " $rep $tol ":" $wtet $woct $w110d $w111d $wvac $wdivac >> Summary.dat
done
done
#mkdir LogFiles FormData
mv log.* LogFiles/
mv *_defectE.dat FormData/
rm -f *_bcc.dump
