#!/bin/bash
repin=$1
tolin=$2
exe="/ascldap/users/mitwood/Documents/LAMMPS_Builds/trunk/src/lmp_kokkos_mpi_only"
pair_file="potential.mod"
cores=36

############Defect Formation Energies######################
j=0
rm -f lastcol2 tmp_defectE.dat Summary.dat
alat=2.2860
mass1=183.84
mass2=9.012182
xtal=hcp
type=2
for rep in $(seq $repin 1 $repin)
do
for tol in $(seq $tolin 2 $tolin)
do
j=0
rm -f lastcol2 tmp_defectE.dat
for i in perf_hcp BCrowd_hcp BOct_hcp BTet_hcp Oct_hcp BSplit_hcp Crowd_hcp Tet_hcp Vac_hcp
do
let j=$j+1
mpiexec -np ${cores} ${exe} -in in.snap_${i} -v pairfile ${pair_file} -v size ${rep} -v elimit 1E-${tol} -v flimit 1E-${tol} -v alat ${alat} -v mass1 ${mass1} -v mass2 ${mass2} -v type ${type} > log.${i}_${rep}_${tol}
rperf_petot=`grep "RELAXED PE PEATOM" log.perf_hcp_${rep}_${tol} | awk '{print($4)}'`
rperf_peatom=`grep "RELAXED PE PEATOM" log.perf_hcp_${rep}_${tol} | awk '{print($5)}'`
rel_petot=`grep "RELAXED PE PEATOM" log.${i}_${rep}_${tol} | awk '{print($4)}'`
rel_peatom=`grep "RELAXED PE PEATOM" log.${i}_${rep}_${tol} | awk '{print($5)}'`
if [ ${#rel_petot} -gt 0 ]; then
echo $i "PEATOM" $rel_petot $rperf_peatom $rep $tol >> tmp_defectE.dat
else
echo $i " PEATOM 0.0 " $rperf_peatom $rep $tol >> tmp_defectE.dat
fi
mv tmp.dump Relaxed_${i}.dump
done
mv tmp_defectE.dat ${rep}_${tol}_defectE.dat

############Error Calculation######################
input=${rep}_${tol}_defectE.dat
errBC=`awk '{if($1=="BCrowd_hcp") print($3-($4*(4.0*'"$rep"'**3+1)))}' $input`
errBO=`awk '{if($1=="BOct_hcp")   print($3-($4*(4.0*'"$rep"'**3+1)))}' $input`
errBT=`awk '{if($1=="BTet_hcp")   print($3-($4*(4.0*'"$rep"'**3+1)))}' $input`
errO=`awk '{if($1=="Oct_hcp")    print($3-($4*(4.0*'"$rep"'**3+1)))}' $input`
errBS=`awk '{if($1=="BSplit_hcp") print($3-($4*(4.0*'"$rep"'**3+1)))}' $input`
errC=`awk '{if($1=="Crowd_hcp")  print($3-($4*(4.0*'"$rep"'**3+1)))}' $input`
errT=`awk '{if($1=="Tet_hcp")    print($3-($4*(4.0*'"$rep"'**3+1)))}' $input`
errV=`awk '{if($1=="Vac_hcp")    print($3-($4*(4.0*'"$rep"'**3-1)))}' $input`
errP=`awk '{if($1=="perf_hcp")   print(-1.0*$4)}' $input`

echo "--------" $rep $tol "--------"
echo $errBC  " BCrowd (Unstable)"
echo $errBO  " BOcta (4.20)"
echo $errBT  " BTetra (Unstable)"
echo $errO  " Octa (5.24)"
echo $errBS  " BSplit (4.30)"
echo $errC  " Crowd (4.39)"
echo $errT  " Tetra (5.22)"
echo $errV  " Vacancy (0.81)"

coeffs=`tail -n56 WBe.snapcoeff | awk '{ sum+=($1*$1)**(0.5) ; n++} END {print(sum/n); }'`
echo "Be " $rep $tol ":" $errBC $errBO $errBT $errO $errBS $errC $errT $errV $errP >> Summary.dat
done
done
#mkdir LogFiles FormData
mv log.* LogFiles/
mv *_defectE.dat FormData/
rm -f *_hcp.dump
