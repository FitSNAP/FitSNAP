from phonolammps import Phonolammps
from phonopy import Phonopy

phlammps = Phonolammps('in.phonons',
                       supercell_matrix=[[3, 0, 0],
                                         [0, 3, 0],
                                         [0, 0, 3]])

unitcell = phlammps.get_unitcell()
force_constants = phlammps.get_force_constants()
supercell_matrix = phlammps.get_supercell_matrix()
bands = phlammps.plot_phonon_dispersion_bands()

phonon = Phonopy(unitcell,
                 supercell_matrix,bands)

phonon.set_force_constants(force_constants)
phonon.set_mesh([20, 20, 20],is_eigenvectors=True,is_mesh_symmetry=False)

phonon.set_total_DOS()
phonon.write_total_DOS()
phonon.plot_total_DOS().show()

phonon.set_partial_DOS()
phonon.write_partial_DOS()

phonon.set_thermal_properties()
phonon.write_yaml_thermal_properties()
phonon.plot_thermal_properties().show()
