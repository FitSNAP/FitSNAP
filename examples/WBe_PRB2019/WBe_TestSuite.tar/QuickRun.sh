#!/bin/bash
repin=$1
tolin=15
cores=16
alat=3.1804
mass1=183.84
mass2=9.012182
xtal=bcc
type=1
exe="/ascldap/users/mitwood/Documents/LAMMPS_Builds/trunk/src/lmp_kokkos_mpi_only"
pair_file="potential.mod"
i=perf_bcc

mpiexec -np ${cores} ${exe} -in in.snap_${i} -v pairfile ${pair_file} -v size ${rep} -v elimit 1E-${tol} -v flimit 1E-${tol} -v alat ${alat} -v mass1 ${mass1} -v mass2 ${mass2} -v type ${type} > log.${i}_${rep}_${tol}

