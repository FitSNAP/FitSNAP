#!/bin/bash
exe="/ascldap/users/mitwood/Documents/LAMMPS_Builds/trunk/src/lmp_kokkos_mpi_only"
pair_file="potential.mod"
cores=36
mass1=183.84
mass2=9.012182
############Cohesive Energies######################
alat=2.2860
mass=9.012182
xtal=hcp
type=2
mpiexec -np ${cores} ${exe} -in in.snap_Ecoh -v pairfile ${pair_file} -v type ${type} -v alat ${alat} -v mass1 ${mass1} -v mass2 ${mass2} -v xtal ${xtal} -screen none >& screen_Ecoh.out
mv log.lammps log.Ec_hcp
ecHCP=`grep "^UNMIN PE PEATOM"  log.Ec_hcp | awk '{if($5<-0.1)print($5)}' | sort -nrk1,1 | tail -n1`

alat=3.16571
xtal=fcc
mpiexec -np ${cores} ${exe} -in in.snap_Ecoh -v pairfile ${pair_file} -v type ${type} -v alat ${alat} -v mass1 ${mass1} -v mass2 ${mass2} -v xtal ${xtal} -screen none >& screen_Ecoh.out
mv log.lammps log.Ec_fcc
ecFCC=`grep "^UNMIN PE PEATOM"  log.Ec_fcc | awk '{if($5<-0.1)print($5)}' | sort -nrk1,1 | tail -n1`

alat=2.53826
xtal=bcc
mpiexec -np ${cores} ${exe} -in in.snap_Ecoh -v pairfile ${pair_file} -v type ${type} -v alat ${alat} -v mass1 ${mass1} -v mass2 ${mass2} -v xtal ${xtal} -screen none >& screen_Ecoh.out
mv log.lammps log.Ec_bcc
ecBCC=`grep "^UNMIN PE PEATOM"  log.Ec_bcc | awk '{if($5<-0.1)print($5)}' | sort -nrk1,1 | tail -n1`

alat=2.20
xtal=sc
mpiexec -np ${cores} ${exe} -in in.snap_Ecoh -v pairfile ${pair_file} -v type ${type} -v alat ${alat} -v mass1 ${mass1} -v mass2 ${mass2} -v xtal ${xtal} -screen none >& screen_Ecoh.out
mv log.lammps log.Ec_sc
ecSC=`grep "^UNMIN PE PEATOM"  log.Ec_sc | awk '{if($5<-0.1)print($5)}' | sort -nrk1,1 | tail -n1`

alat=4.94
xtal=diamond
mpiexec -np ${cores} ${exe} -in in.snap_Ecoh -v pairfile ${pair_file} -v type ${type} -v alat ${alat} -v mass1 ${mass1} -v mass2 ${mass2} -v xtal ${xtal} -screen none >& screen_Ecoh.out
mv log.lammps log.Ec_dia
ecDIA=`grep "^UNMIN PE PEATOM"  log.Ec_dia | awk '{if($5<-0.1)print($5)}' | sort -nrk1,1 | tail -n1`

echo "Be:"
echo $ecHCP  " HCP Cohesive (-3.32)"
echo $ecFCC  " FCC Cohesive (-3.24)"
echo $ecBCC  " BCC Cohesive (-3.22)"
echo $ecSC  " SC Cohesive (-2.33)"
echo $ecDIA  " DIA Cohesive (-1.73)"
echo "----------------------------------------------"
alat=3.1803
xtal=bcc
type=1
mpiexec -np ${cores} ${exe} -in in.snap_Ecoh -v pairfile ${pair_file} -v type ${type} -v alat ${alat} -v mass1 ${mass1} -v mass2 ${mass2} -v xtal ${xtal} -screen none >& screen_Ecoh.out
mv -f log.lammps log.Ec_wbcc
wecBCC=`grep "^UNMIN PE PEATOM"  log.Ec_wbcc | awk '{if($5<-0.1)print($5)}' | sort -nrk1,1 | tail -n1`
echo "W:"
echo $wecBCC  " BCC Cohesive (-8.90)"
echo "----------------------------------------------"

xtal=B2
mpiexec -np ${cores} ${exe} -in in.snap_Ecoh_FromData -v pairfile ${pair_file} -v mass1 ${mass1} -v mass2 ${mass2} -v xtal ${xtal} -screen none >& screen_Ecoh.out
mv -f log.lammps log.Ec_B2
wbeB2=`grep "^UNMIN PE PEATOM"  log.Ec_B2 | awk '{if($5<-0.1)print($4/27/8)}' | sort -nrk1,1 | tail -n1`

xtal=L12
mpiexec -np ${cores} ${exe} -in in.snap_Ecoh_FromData -v pairfile ${pair_file} -v mass1 ${mass1} -v mass2 ${mass2} -v xtal ${xtal} -screen none >& screen_Ecoh.out
mv -f log.lammps log.Ec_L12
wbeL12=`grep "^UNMIN PE PEATOM"  log.Ec_L12 | awk '{if($5<-0.1)print($4/27)}' | sort -nrk1,1 | tail -n1`

xtal=C14
mpiexec -np ${cores} ${exe} -in in.snap_Ecoh_FromData -v pairfile ${pair_file} -v mass1 ${mass1} -v mass2 ${mass2} -v xtal ${xtal} -screen none >& screen_Ecoh.out
mv -f log.lammps log.Ec_C14
wbeC14=`grep "^UNMIN PE PEATOM"  log.Ec_C14 | awk '{if($5<-0.1)print($4/27/4)}' | sort -nrk1,1 | tail -n1`

xtal=C15
mpiexec -np ${cores} ${exe} -in in.snap_Ecoh_FromData -v pairfile ${pair_file} -v mass1 ${mass1} -v mass2 ${mass2} -v xtal ${xtal} -screen none >& screen_Ecoh.out
mv -f log.lammps log.Ec_C15
wbeC15=`grep "^UNMIN PE PEATOM"  log.Ec_C15 | awk '{if($5<-0.1)print($4/27/2)}' | sort -nrk1,1 | tail -n1`

xtal=C36
mpiexec -np ${cores} ${exe} -in in.snap_Ecoh_FromData -v pairfile ${pair_file} -v mass1 ${mass1} -v mass2 ${mass2} -v xtal ${xtal} -screen none >& screen_Ecoh.out
mv -f log.lammps log.Ec_C36
wbeC36=`grep "^UNMIN PE PEATOM"  log.Ec_C36 | awk '{if($5<-0.1)print($4/27/8)}' | sort -nrk1,1 | tail -n1`

xtal=D2b
mpiexec -np ${cores} ${exe} -in in.snap_Ecoh_FromData -v pairfile ${pair_file} -v mass1 ${mass1} -v mass2 ${mass2} -v xtal ${xtal} -screen none >& screen_Ecoh.out
mv -f log.lammps log.Ec_D2b
wbeD2b=`grep "^UNMIN PE PEATOM"  log.Ec_D2b | awk '{if($5<-0.1)print($4/27)}' | sort -nrk1,1 | tail -n1`

echo "WBe: Energy/Formula Unit"
echo "B2  (WBe):  " $wbeB2 "L12 (WBe3): " $wbeL12 "C14 (WBe2):  " $wbeC14
echo "C15 (WBe2): " $wbeC15 "C36 (WBe2): " $wbeC36 "D2b (WBe12): " $wbeD2b
echo "----------------------------------------------"
ecB2=`awk '{print('"$wbeB2"'-(1.0*'"$wecBCC"'+1.0*'"$ecHCP"'))}' in.snap_Ecoh | tail -n1`
ecL12=`awk '{print('"$wbeL12"'-(1.0*'"$wecBCC"'+3.0*'"$ecHCP"'))}' in.snap_Ecoh | tail -n1`
ecC14=`awk '{print('"$wbeC14"'-(1.0*'"$wecBCC"'+2.0*'"$ecHCP"'))}' in.snap_Ecoh | tail -n1`
ecC15=`awk '{print('"$wbeC15"'-(1.0*'"$wecBCC"'+2.0*'"$ecHCP"'))}' in.snap_Ecoh | tail -n1`
ecC36=`awk '{print('"$wbeC36"'-(1.0*'"$wecBCC"'+2.0*'"$ecHCP"'))}' in.snap_Ecoh | tail -n1`
ecD2b=`awk '{print('"$wbeD2b"'-(1.0*'"$wecBCC"'+12.0*'"$ecHCP"'))}' in.snap_Ecoh | tail -n1`

echo "WBe: Formation Energy w.r.t. W,Be Ec"
echo "B2  (WBe):  " $ecB2 "L12 (WBe3): " $ecL12 "C14 (WBe2):  " $ecC14
echo "C15 (WBe2): " $ecC15 "C36 (WBe2): " $ecC36 "D2b (WBe12): " $ecD2b
echo "----------------------------------------------"
