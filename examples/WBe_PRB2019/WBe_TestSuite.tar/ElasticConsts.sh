#!/bin/bash
exe="/ascldap/users/mitwood/Documents/LAMMPS_Builds/trunk/src/lmp_kokkos_mpi_only"
pair_file="potential.mod"
cores=36
############Elastic Constants######################
alat=2.2860
xtal=hcp
type=2
mpiexec -np 1 ${exe} -v alat ${alat} -v type ${type} -v xtal ${xtal} -in in.elastic -screen none >& ./run_script.out
grep "^Elastic Constant" log.lammps >> ./run_script.out
c11=`grep "^Elastic Constant C11all" log.lammps | awk '{print($5)}'`
c12=`grep "^Elastic Constant C12all" log.lammps | awk '{print($5)}'`
c13=`grep "^Elastic Constant C13all" log.lammps | awk '{print($5)}'`
c33=`grep "^Elastic Constant C33all" log.lammps | awk '{print($5)}'`
c44=`grep "^Elastic Constant C44all" log.lammps | awk '{print($5)}'`

c11err=`awk '{print(100*(((1-1.0*'"$c11"'/302.7)**(2.0))**(1.0/2.0)))}' run_script.out | tail -n1`
c12err=`awk '{print(100*(((1-1.0*'"$c12"'/29.4)**(2.0))**(1.0/2.0)))}' run_script.out | tail -n1`
c13err=`awk '{print(100*(((1-1.0*'"$c13"'/16)**(2.0))**(1.0/2.0)))}' run_script.out | tail -n1`
c33err=`awk '{print(100*(((1-1.0*'"$c33"'/368)**(2.0))**(1.0/2.0)))}' run_script.out | tail -n1`
c44err=`awk '{print(100*(((1-1.0*'"$c44"'/166.9)**(2.0))**(1.0/2.0)))}' run_script.out | tail -n1`

Bulk=`echo "scale=6; 121.78 - ((1.0/9.0)*(2*$c11 + 1.0*$c33 + 2.0*$c12 + 4.0*$c13))" | bc`
ShearA=`echo "scale=6; 137 - ((1.0/2.0)*(1.0*$c11 - 2.0*$c12))" | bc`
ShearB=`echo "scale=6; 167 - 1.0*$c44" | bc`
ShearC=`echo "scale=6; 167.33 - ((1.0/6.0)*(1.0*$c11 + 2.0*$c33 + 1.0*$c12 - 4.0*$c13))" | bc`
Delta=`echo "scale=6; -17.33 - ((1.0/3.0)*(1.0*$c11 - 1.0*$c33 + 1.0*$c12 - 1.0*$c13))" | bc`
Net=`awk '{print((('"$Bulk"')**2.0)**(1.0/2.0)+(('"$ShearA"')**2.0)**(1.0/2.0)+(('"$ShearB"')**2.0)**(1.0/2.0)+(('"$ShearC"')**2.0)**(1.0/2.0)+(('"$Delta"')**2.0)**(1.0/2.0))}' run_script.out | tail -n1`
echo "B:" $Bulk "Sa: " $ShearA "Sb: " $ShearB "Sc: " $ShearC "D: " $Delta "Net: " $Net
echo "----------------------------------------------"
echo "Be HCP: " $c11 $c12 $c13 "C11 C12 C13 " 
echo "Be HCP: " $c33 $c44 " C33 C44 " 
echo "Be HCP: % Err " $c11err $c12err $c13err $c33err $c44err
echo "----------------------------------------------"

alat=3.1803
xtal=bcc
type=1
mpiexec -np 1 ${exe} -v alat ${alat} -v type ${type} -v xtal ${xtal} -in in.elastic -screen none >& ./run_script.out
grep "^Lattice Constant abcc" log.lammps > ./run_script.out
grep "^Elastic Constant C11bcc" log.lammps >> ./run_script.out
grep "^Elastic Constant C12bcc" log.lammps >> ./run_script.out
grep "^Elastic Constant C44bcc" log.lammps >> ./run_script.out
c11=`grep "^Elastic Constant C11all" log.lammps | awk '{print($5)}'`
c12=`grep "^Elastic Constant C12all" log.lammps | awk '{print($5)}'`
c44=`grep "^Elastic Constant C44all" log.lammps | awk '{print($5)}'`

latcerr=`grep "^Lattice Constant abcc" log.lammps  | awk '{print(100*(((1-$5/3.1803)**(2.0))**(1.0/2.0)))}'`
c11err=`grep "^Elastic Constant C11bcc" log.lammps | awk '{print(((($5-517)**(2.0))**(1.0/2.0)))}'`
c12err=`grep "^Elastic Constant C12bcc" log.lammps | awk '{print(((($5-198)**(2.0))**(1.0/2.0)))}'`
c44err=`grep "^Elastic Constant C44bcc" log.lammps | awk '{print(((($5-142)**(2.0))**(1.0/2.0)))}'`

echo "W " $c11 $c12 $c44 "C11 C12 C44 " $c11err $c12err $c44err
echo "----------------------------------------------"

xtal=C14
mpiexec -np 1 ${exe} -v xtal ${xtal} -in in.elastic_fromdata -screen none >& ./run_script.out
grep "^Lattice Constant abcc" log.lammps > ./run_script.out
grep "^Elastic Constant C11bcc" log.lammps >> ./run_script.out
grep "^Elastic Constant C12bcc" log.lammps >> ./run_script.out
grep "^Elastic Constant C44bcc" log.lammps >> ./run_script.out
c11=`grep "^Elastic Constant C11all" log.lammps | awk '{print($5)}'`
c12=`grep "^Elastic Constant C12all" log.lammps | awk '{print($5)}'`
c13=`grep "^Elastic Constant C13all" log.lammps | awk '{print($5)}'`
c33=`grep "^Elastic Constant C33all" log.lammps | awk '{print($5)}'`
c44=`grep "^Elastic Constant C44all" log.lammps | awk '{print($5)}'`

c11err=`awk '{print(100*(((1-1.0*'"$c11"'/451)**(2.0))**(1.0/2.0)))}' run_script.out | tail -n1`
c12err=`awk '{print(100*(((1-1.0*'"$c12"'/98)**(2.0))**(1.0/2.0)))}' run_script.out | tail -n1`
c13err=`awk '{print(100*(((1-1.0*'"$c13"'/107)**(2.0))**(1.0/2.0)))}' run_script.out | tail -n1`
c33err=`awk '{print(100*(((1-1.0*'"$c33"'/436)**(2.0))**(1.0/2.0)))}' run_script.out | tail -n1`
c44err=`awk '{print(100*(((1-1.0*'"$c44"'/170)**(2.0))**(1.0/2.0)))}' run_script.out | tail -n1`

echo "WBe C14: " $c11 $c12 $c13 "C11 C12 C13 " 
echo "WBe C14: " $c33 $c44 " C33 C44 " 
echo "WBe C14: % Err " $c11err $c12err $c13err $c33err $c44err
